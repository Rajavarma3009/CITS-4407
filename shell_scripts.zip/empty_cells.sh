#!/bin/bash
filename="$1"
sep="$2"
awk -F"$sep" '
NR == 1 {
	gsub(/\r/, "", $0)
	MX = split($0, HDR)
	for (i = 1; i <= MX; i++) COUNT[i] = 0
	next
}
{
	gsub(/\r/, "", $0)
	for (i = 1; i <= MX; i++) {
		if ($i == "") COUNT[i]++
	}
}
END {
	for (i = 1; i <= MX; i++) {
		printf "%s: %d \n", HDR[i], COUNT[i]
	}
}
' $filename
