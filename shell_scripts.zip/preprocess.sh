#!/bin/bash
filename="$1"
# create a temporary file to temporarily store the preprocessed file
tempfile=$(mktemp)

cat "$filename" | tr ';' '\t'| tr -d '\r'| sed -E 's/\b([0-9]+),([0-9]{1,})\b/\1.\2/g'| tr -cd '\0-\177' > "$tempfile"

maxID=$(awk -F'\t' 'NR>1 && $1 ~ /^[0-9]+$/ && $1 > max { max=$1 } END { print max }' "$tempfile")
awk -v id="$((maxID + 1))" '
BEGIN {
	FS=OFS="\t"
}
NR==1 { print; next }
{
	if ($1 == "") {
		$1 = id;
		id++;
	}
	print
}' "$tempfile"