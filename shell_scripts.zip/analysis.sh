#!/bin/bash

filename="$1"
# Q1 - Most Popular Game Mechanic
cut -f13 $filename | tr ',' '\n' | sed '/^$/d' | sed 's/^ *//;s/ *$//' | sort | uniq -c | sort -nr > mechanics_count.txt
popular_mechanics=$(head -1 mechanics_count.txt | awk '{$1=$1; print}')
mechanics_count=$(echo "$popular_mechanics" | awk '{print $1}')
mechanics_name=$(echo "$popular_mechanics" | cut -d' ' -f2-)
rm mechanics_count.txt
echo "The most popular game mechanics is $mechanics_name found in $mechanics_count games"

# Q2 - Most Popular Game Domain
cut -f14 $filename | tr ',' '\n' | sed '/^$/d' | sed 's/^ *//;s/ *$//' | sort | uniq -c | sort -nr > domains_count.txt
popular_domain=$(head -1 domains_count.txt | awk '{$1=$1; print}')
domain_count=$(echo "$popular_domain" | awk '{print $1}')
domain_name=$(echo "$popular_domain" | cut -d' ' -f2-)
rm domains_count.txt
echo "The most popular style of game is $domain_name found in $domain_count games"

# Q3 - Pearson Correlation
correlation() {
	awk -F'\t' -v xcol="$1" -v ycol="$2" '
	BEGIN {OFS="\t"}
	NR==1{
		for (i = 1;i <= NF; i++){
			if ($i == xcol) x = i;
			if ($i == ycol) y = i;
		}
	}
	NR > 1 && $x != "" && $y != ""{
		sum_x += $x;
		sum_y += $y;
		xSS += $x * $x;
		ySS += $y * $y;
		sum_xy += $x * $y;
		rows++;
	}
	END {
		numerator = rows * sum_xy - sum_x * sum_y;
		denominator = sqrt((rows * xSS - sum_x * sum_x) * (rows * ySS - sum_y * sum_y));
		if (denominator == 0) {
			print "NaN";
		} else {
			printf "%.3f", numerator / denominator;
		}
	}' $filename
}

# Year Published vs Rating Average cor
corr_year_rate=$(correlation "Year Published" "Rating Average")

# Complexity Average vs Rating Average cor
corr_complexity_rate=$(correlation "Complexity Average" "Rating Average")

# Print the correlations
echo "The correlation between the year of publication and the average rating is $corr_year_rate"
echo "The correlation between the complexity of a game and its average rating is $corr_complexity_rate"
